let yellowContainerId = document.getElementById('yellowBtnId');
let blueContainerId = document.getElementById('blueBtnId');
let redContainerId = document.getElementById('redBtnId');
let greenContainerId = document.getElementById('greenBtnId');
let yellow = document.getElementById('yellow');
let blue = document.getElementById('blue');
let red = document.getElementById('red');
let green = document.getElementById('green');

function yellowBtn() {
    yellowContainerId.classList.add('left-arrow');
    yellow.classList.add('change-color');
}

function blueBtn() {
    blueContainerId.classList.add('left-arrow');
    blue.classList.add('change-color');
}

function redBtn() {
    redContainerId.classList.add('left-arrow');
    red.classList.add('change-color');
}

function greenBtn() {
    greenContainerId.classList.add('left-arrow');
    green.classList.add('change-color');
}

function onReset() {
    yellowContainerId.classList.remove('left-arrow');
    yellow.classList.remove('change-color');
    blueContainerId.classList.remove('left-arrow');
    blue.classList.remove('change-color');
    redContainerId.classList.remove('left-arrow');
    red.classList.remove('change-color');
    greenContainerId.classList.remove('left-arrow');
    green.classList.remove('change-color');
}